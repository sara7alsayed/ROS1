    #!/usr/bin/env python3
import rospy
from client_server.srv import mult, multResponse

def callback(req):
    decrypted = ""  # Initialize decrypted string
    for i in range(len(req.characrer)):  # Use range(len()) for iteration
        decrypted += chr(req.b ^ ord(req.characrer[i]))  # Modify decrypted string
    print(decrypted)
    return multResponse(decrypted)  # Return the response

rospy.init_node("server")
rospy.Service("my_service", mult, callback)
rospy.spin()
 

 
