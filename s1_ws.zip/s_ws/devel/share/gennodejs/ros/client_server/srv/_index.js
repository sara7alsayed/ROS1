
"use strict";

let mult = require('./mult.js')

module.exports = {
  mult: mult,
};
